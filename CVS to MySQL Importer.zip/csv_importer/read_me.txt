
 >>> PHP CSV Importer

 > Author:  Matthew Lindley
 > E-mail:  sir_tripod@hotmail.com
 > Verson:  1.3
 > Date:  20th December 2002

 This script will allow you to import CSV files and put
 the results into a database.

 >>> What this script is:
 - A simple script for importing CSV files into a database 
 - Quite handy.
 - Easy-to-use.
 - To be used as-is.  DO NOT use this on any "critical" system as I cannot and will not be held responsible for any result of the use of this program.  Test it, make sure it works first.  By you using this script, you agree to all of this.

 >>> What this script isn't:
 - Secure.
 - Finished.
 - Commented.  (Bad habit, sorry)
 - Coded with the best code, but it works well.

 >>> "To-Do" list:
 - User-error reporting.
 - Code commenting.
 - Feedback system.
 - Registration system (free).
 - Tutorial?


 >>> Costs, feedback and registration

 I'm sad, I enjoy programming.  It's a challenge.  That's
 why I'm not charging you for it.  It's free!  We all love 
 free stuff, so here you go!  d:-)

 All I do ask is that you send me an e-mail saying you've
 got it and let me know how you get on with it.  Not a lot
 to ask considering the amount of time and effort I've put
 into all this...

 Thanks for downloading it.  Happy importing!

 E-mail address: sir_tripod@hotmail.com
