<?php 
//Connect to datbase
	require_once('functions.php');	
?>
<?php
	if (!isset($_SESSION['manage'])) {
		header("Location:login.php");
		exit;
	} elseif (isset($_SESSION['manage'])) {
?>
<?php	 
//Echo the items
	if (isset ($_GET['id'])) {
		$id = $_GET['id'];
	}
	
	if (isset($_POST['submit'])) {
		$title = mysql_real_escape_string($_POST['title']);
		$description = mysql_real_escape_string($_POST['description']);
		$writerDate = mysql_real_escape_string($_POST['writerDate']);
		$producerDate = mysql_real_escape_string($_POST['producerDate']);
		$debut = mysql_real_escape_string($_POST['debut']);
	
		$taskGrabber = serialize($_POST['task']);
		$task = mysql_real_escape_string($taskGrabber);
		
		if (isset ($_GET['id'])) {
			$updateQuery = "UPDATE schedule SET `title` = '{$title}', `description` = '{$description}', `writerDate` = '{$writerDate}', `producerDate` = '{$producerDate}', `debut` = '{$debut}', `name` = '{$task}' WHERE id = '{$id}'";
					
			if (mysql_query($updateQuery, $connDBA)) {
				if (isset($_SESSION['edit'])) {
					header ("Location: index.php?edit");
					exit;
				} else {
					header ("Location: index.php");
					exit;
				}
			}	
		} elseif(!isset ($_GET['id'])) {
			$newPositionGrabber = mysql_query("SELECT * FROM schedule ORDER BY id DESC", $connDBA);
			$newPositionArray = mysql_fetch_array($newPositionGrabber);
			$newPosition = $newPositionArray['id']+1;
			$newItemQuery = "INSERT INTO schedule (id, title, description, writerDate, producerDate, debut, name, writerComplete, producerComplete) VALUES ('{$newPosition}', '{$title}', '{$description}', '{$writerDate}', '{$producerDate}', '{$debut}', '{$task}', '', '')";
					
			if (mysql_query($newItemQuery, $connDBA)) {
				if (isset($_SESSION['edit'])) {
					header ("Location: index.php?edit");
					exit;
				} else {
					header ("Location: index.php");
					exit;
				}
			}			
		}
	}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Add Schedule Item</title>
<script type="text/javascript" src="editor/tiny_mce.js"></script>
<script type="text/javascript" src="javascripts/common/tiny_mce_simple.js"></script>
<script type="text/javascript" src="javascripts/validation/validatorCore.js"></script>
<script type="text/javascript" src="javascripts/validation/validatorOptions.js"></script>
<script type="text/javascript" src="javascripts/validation/runValidator.js"></script>
<script type="text/javascript" src="javascripts/validation/validateTextarea.js"></script>
<script type="text/javascript" src="javascripts/validation/formErrors.js"></script>
<script type="text/javascript" src="javascripts/common/goToURL.js"></script>
<script type="text/javascript" src="javascripts/common/insertTask.js"></script>
<link href="styles/common/style.css" rel="stylesheet" type="text/css" />
<link href="styles/validation/validatorStyle.css" rel="stylesheet" type="text/css" />
<link href="styles/validation/validateTextarea.css"rel="stylesheet" type="text/css" />
<link href="http://pavcs.blackboard.com/ui/styles/blackboard.css" rel="stylesheet" type="text/css" />
<link href="http://pavcs.blackboard.com/ui/styles/palette.css" rel="stylesheet" type="text/css" />
<link href="http://pavcs.blackboard.com/ui/styles/grid.css" rel="stylesheet" type="text/css" />
</head>

<body>
<table border="0" cellpadding="0" cellspacing="0" width="100%">
  <tbody>
    <tr>
      <td class="bLight" valign="middle"><span class="breadcrumb"> <a href="http://pavcs.blackboard.com/bin/common/course.pl?course_id=_624_1" target="content">THE PAVCS BELL NEWS MAGAZINE (ORG_KILBERT)</a></span><span class="breadcrumb"> &gt; <a href="<?php if (isset($_SESSION['edit'])) {
				echo "index.php?edit";
			} else {
				echo "index.php";
			}?>">Bell Productivity Manager</a> > Add Schedule Item</span></td>
      <td class="bLight" align="right" nowrap="nowrap">&nbsp;</td>
    </tr>
    <tr height="5">
      <td>&nbsp;</td>
    </tr>
  </tbody>
</table>
<h1 style="font-size: 16.625px; line-height: 20px;" class="pageTitle"><a style="font-size: 16.625px; line-height: 20px;" href=""></a><img src="http://pavcs.blackboard.com/images/ci/sets/set08/document_on.gif" alt="Object" align="absmiddle" border="0" /> Add Schedule Item</h1>
  <form action="schedule.php<?php if (isset ($_GET['id'])) {echo "?id=" . $id;} ?>" method="post" id="validate" onsubmit="return errorsOnSubmit(this);">
    <p>
      <?php if (isset ($_GET['id'])) {echo "<input type=\"hidden\" value=\">" . $id . "\">";} ?>
    </p>
    <div class="catDivider"><img src="images/numbering/1.gif" alt="1." width="22" height="22" /> Task Name</div>
    <div class="stepContent">
    <blockquote>
      <p>Title<span class="require">*</span>:</p>
      <blockquote>
        <p>
          <input name="title" type="text" id="title" size="50" autocomplete="off" class="validate[required]"
          <?php
		  //Display a value here if user is editing
		  		if (isset ($_GET['id'])) {
					$title = mysql_fetch_array(mysql_query("SELECT * FROM schedule WHERE id = '{$id}'", $connDBA));
					echo " value=\"" . htmlentities(stripslashes($title['title'])) . "\"";
				}
		  ?>
           />
        </p>
      </blockquote>
      <p>Description<span class="require">*</span>:</p>
      <blockquote>
        <p><span id="descriptionCheck">
          <textarea name="description" id="description" cols="50" rows="5"><?php
		  //Display a value here if user is editing
		  		if (isset ($_GET['id'])) {
					$description = mysql_fetch_array(mysql_query("SELECT * FROM schedule WHERE id = '{$id}'", $connDBA));
					echo stripslashes($description['description']);
				}
		  ?>
          </textarea>
        <span class="textareaRequiredMsg"></span></span></p>
      </blockquote>
    </blockquote>
    </div>
    <div class="catDivider"><img src="images/numbering/2.gif" alt="2." width="22" height="22" /> Task Settings</div>
    <div class="stepContent">
    <blockquote>
      <p>Writer due Date<span class="require">*</span>:</p>
      <blockquote>
        <p>
          <input name="writerDate" type="text" id="writerDate" size="50" autocomplete="off" class="validate[required]"<?php
		  //Display a value here if user is editing
		  		if (isset ($_GET['id'])) {
					$writerDate = mysql_fetch_array(mysql_query("SELECT * FROM schedule WHERE id = '{$id}'", $connDBA));
					echo " value=\"" . htmlentities(stripslashes($writerDate['writerDate'])) . "\"";
				}
		  ?> />
        </p>
      </blockquote>
      <p>Producer due Date<span class="require">*</span>:</p>
      <blockquote>
        <p>
          <input name="producerDate" type="text" id="producerDate" size="50" autocomplete="off" class="validate[required]"
          <?php
		  //Display a value here if user is editing
		  		if (isset ($_GET['id'])) {
					$producerDate = mysql_fetch_array(mysql_query("SELECT * FROM schedule WHERE id = '{$id}'", $connDBA));
					echo " value=\"" . htmlentities(stripslashes($producerDate['producerDate'])) . "\"";
				}
		  ?>
           />
        </p>
      </blockquote>
      <p>Debut<span class="require">*</span>:</p>
      <blockquote>
        <p>
          <input name="debut" type="text" id="debut" size="50" autocomplete="off" class="validate[required]"
          <?php
		  //Display a value here if user is editing
		  		if (isset ($_GET['id'])) {
					$debut = mysql_fetch_array(mysql_query("SELECT * FROM schedule WHERE id = '{$id}'", $connDBA));
					echo " value=\"" . htmlentities(stripslashes($debut['debut'])) . "\"";
				}
		  ?>
           />
        </p>
      </blockquote>
    </blockquote>
    </div>
    <div class="catDivider"><img src="images/numbering/3.gif" alt="3." width="22" height="22" /> Tasks</div>
    <div class="stepContent">
    <blockquote>
      <p>
    <?php
	//The schedule loop
	//Check to see any tasks exist
		$taskCheckGrabber = mysql_query("SELECT * FROM schedule", $connDBA);
		$taskCheckArray = mysql_fetch_array($taskCheckGrabber);
		$taskCheckResult = $taskCheckArray['name'];
			 if (empty ($taskCheckResult)) {
				 $taskCheck = 1;
			 } else {
				$taskCheck = 0;
			 }
			 
	//Echo the items
		if (isset ($_GET['id'])) {
			$valueGrabber = mysql_query("SELECT * FROM schedule WHERE id = '{$id}'", $connDBA);	
			$value = mysql_fetch_array($valueGrabber);
			$items = unserialize($value['name']);
			$count = 0;
			
			echo "<table width=\"100%\" name=\"items\" id=\"items\" style=\"border-spacing:0px; padding:0px;\">";
			while (list($itemKey, $itemArray) = each($items)) {
				echo "<tr><td><input name=\"task[]\" type=\"text\" id=\"" . $count++ . "\" size=\"50\" class=\"validate[required]\" autocomplete=\"off\" value=\"" . htmlentities(stripslashes ($itemArray)) . "\" /></td></tr>";
			}
			echo "</table>";
		} else {
			echo "<table width=\"100%\" border=\"0\" id=\"items\" style=\"border-spacing:0px; padding:0px;\">
				<tr>
				  <td><label>
					<input name=\"task[]\" type=\"text\" id=\"1\" autocomplete=\"off\" class=\"validate[required]\" size=\"50\" />
				  </label></td>
				</tr>
			  </table>";
		}
	?>
      </p>
      <p>
        <input value="Add Another Task" type="button" onclick="appendRow('items', '&lt;input name=\'task[]\' type=\'text\' id=\'', '\' autocomplete=\'off\'  class=\'validate[required]\' size=\'50\' /&gt;')" />
        <input value="Remove Last Task" type="button" onclick="deleteLastRow('items')" />
      </p>
    </blockquote>
    </div>
    <div class="catDivider"><img src="images/numbering/4.gif" alt="4." width="22" height="22" /> Submit</div>
    <div class="stepContent">
    <blockquote>
    <p>
      <input type="submit" name="submit" id="submit" value="Submit" onclick="tinyMCE.triggerSave();" />
      <input name="cancel" type="button" id="cancel" onclick="MM_goToURL('parent','<?php if (isset($_SESSION['edit'])) {
				echo "index.php?edit";
			} else {
				echo "index.php";
			}?>');return document.MM_returnValue" value="Cancel" />
    </p>
    <div id="errorBox" style="display:none;">Some fields are incomplete, please scroll up to correct them.</div>
    </blockquote>
    </div>
</form>
<script type="text/javascript">
<!--
var sprytextarea1 = new Spry.Widget.ValidationTextarea("descriptionCheck");
//-->
</script>
</body>

</html>
<?php }?>