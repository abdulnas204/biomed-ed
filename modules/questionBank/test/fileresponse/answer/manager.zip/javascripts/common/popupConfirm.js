function GP_popupConfirmMsg(msg) {
  document.MM_returnValue = confirm(msg);
}