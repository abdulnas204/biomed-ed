<?php
require_once('functions.php');
	
	if (!isset($_SESSION['manage'])) {
		header("Location:login.php");
		exit;
	} elseif (isset($_SESSION['manage'])) {
?>
<?php
//Execute data in the database
//Add a new announcement
	if (!isset ($_GET['ann'])) {
		if (isset($_POST['submit']) && isset ($_POST['title']) &&  isset ($_POST['content'])) {
			$title = mysql_real_escape_string($_POST['title']);
			$content =  mysql_real_escape_string($_POST['content']);
			$position = $_POST['position'];
			
			$newPageQuery = "INSERT INTO pages (
								title, content, position
							) VALUES (
								'{$title}', '{$content}', '{$position}'
							)";
			
			if (mysql_query($newPageQuery, $connDBA)) {
				if (isset($_SESSION['edit'])) {
					header ("Location: index.php?edit");
					exit;
				} else {
					header ("Location: index.php");
					exit;
				}
			}
		}
//Edit an existing announcement
	} elseif (isset ($_GET['ann'])) {
		if (isset($_POST['submit']) && isset ($_POST['title']) &&  isset ($_POST['content'])) {
				$id = $_GET['ann'];
				$title =  mysql_real_escape_string($_POST['title']);
				$content =  mysql_real_escape_string($_POST['content']);
				
				$editPageQuery = "UPDATE pages SET
					title = '{$title}',
					content = '{$content}'
					WHERE position = '{$id}'";
		
				$editPageQueryResult = mysql_query($editPageQuery, $connDBA);
			if (mysql_affected_rows() == 1) {
				if (isset($_SESSION['edit'])) {
					header ("Location: index.php?edit");
					exit;
				} else {
					header ("Location: index.php");
					exit;
				}
			}
		} 
//If not all of the field are being edited
	} else {
		header ("Location: index.php");
		exit;
	}
?>
<?php
//Grab the announcement content, if it is being edited
	if (isset ($_GET['ann'])) {
		$getPageID = $_GET['ann'];	
		$editPageInfoGrabber = mysql_query("SELECT * FROM pages WHERE position = {$getPageID}", $connDBA);		
		$editPageInfo = mysql_fetch_array($editPageInfoGrabber);
	}
?>
<?php
//The position for a new announcement
	$pageGrabber = mysql_query("SELECT * FROM pages ORDER BY position ASC", $connDBA);		
	$numberCheck = mysql_num_rows($pageGrabber);
	$defaultNumber = $numberCheck+1;
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Manage Announcement</title>
<script type="text/javascript" src="editor/tiny_mce.js"></script>
<script type="text/javascript" src="javascripts/common/tiny_mce_advanced.js"></script>
<script type="text/javascript" src="javascripts/validation/validatorCore.js"></script>
<script type="text/javascript" src="javascripts/validation/validatorOptions.js"></script>
<script type="text/javascript" src="javascripts/validation/runValidator.js"></script>
<script type="text/javascript" src="javascripts/validation/validateTextarea.js"></script>
<script type="text/javascript" src="javascripts/validation/formErrors.js"></script>
<script type="text/javascript" src="javascripts/common/popupConfirm.js"></script>
<script type="text/javascript" src="javascripts/common/goToURL.js"></script>
<link href="styles/common/style.css" rel="stylesheet" type="text/css" />
<link href="styles/validation/validatorStyle.css" rel="stylesheet" type="text/css" />
<link href="styles/validation/validateTextarea.css"rel="stylesheet" type="text/css" />
<link href="http://pavcs.blackboard.com/ui/styles/blackboard.css" rel="stylesheet" type="text/css" />
<link href="http://pavcs.blackboard.com/ui/styles/palette.css" rel="stylesheet" type="text/css" />
<link href="http://pavcs.blackboard.com/ui/styles/grid.css" rel="stylesheet" type="text/css" />
</head>

<body>
<table border="0" cellpadding="0" cellspacing="0" width="100%">
  <tbody>
    <tr>
      <td class="bLight" valign="middle"><span class="breadcrumb"> <a href="http://pavcs.blackboard.com/bin/common/course.pl?course_id=_624_1" target="content">THE PAVCS BELL NEWS MAGAZINE (ORG_KILBERT)</a></span><span class="breadcrumb"> &gt; <a href="<?php if (isset($_SESSION['edit'])) {
				echo "index.php?edit";
			} else {
				echo "index.php";
			}?>">Bell Productivity Manager</a> > Manage Announcement</span></td>
      <td class="bLight" align="right" nowrap="nowrap">&nbsp;</td>
    </tr>
    <tr height="5">
      <td>&nbsp;</td>
    </tr>
  </tbody>
</table>
<h1 style="font-size: 16.625px; line-height: 20px;" class="pageTitle"><a style="font-size: 16.625px; line-height: 20px;" href=""></a><img src="http://pavcs.blackboard.com/images/ci/sets/set08/document_on.gif" alt="Object" align="absmiddle" border="0" /> Manage Announcement</h1>
<form action="announcement.php<?php
  		if (isset ($_GET['ann'])) {
			echo "?ann=" . $editPageInfo['position'];		
		}
  ?>" method="post" id="validate" onsubmit="return errorsOnSubmit(this);">
  <p>
    <input type="hidden" name="position" value="<?php
  		if (!isset ($_GET['ann'])) {
			echo $defaultNumber;
		} else {
  			echo $editPageInfo['position'];
		} 
  ?>" />
  </p>
  <div class="catDivider"><img src="images/numbering/1.gif" alt="1." width="22" height="22" /> Announcement Content</div>
  <div class="stepContent">
    <blockquote>
      <p>Announcement Title<span class="require">*</span>:</p>
      <blockquote>
      <input name="title" type="text" id="title" size="50" autocomplete="off" class="validate[required]"<?php
			if (isset ($_GET['ann'])) {
				echo "value=\"" . htmlentities(stripslashes($editPageInfo['title'])) . "\"";
			}
	  ?> />
      </blockquote>
      <p>Content<span class="require">*</span>:</p>
      <blockquote>
      <span id="contentCheck">
      <textarea name="content" id="content" cols="45" rows="5" style="width:640px; height:320px;" /><?php
			if (isset ($_GET['ann'])) {
				echo stripslashes($editPageInfo['content']);
			}
	  ?></textarea>
      <span class="textareaRequiredMsg"></span></span>
      </blockquote>
    </blockquote>
  </div>
  <div class="catDivider"><img src="images/numbering/2.gif" alt="2." width="22" height="22" /> Submit</div>
  <div class="stepContent">
  <blockquote>
    <p>
      <input type="submit" name="submit" id="submit" value="Submit" onclick="tinyMCE.triggerSave();" />
      <input name="reset" type="reset" id="reset" onclick="GP_popupConfirmMsg('Are you sure you wish to clear the content in this form? \rPress \&quot;cancel\&quot; to keep current content.');return document.MM_returnValue" value="Reset" />
      <input name="cancel" type="button" id="cancel" onclick="MM_goToURL('parent','<?php if (isset($_SESSION['edit'])) {
			echo "index.php?edit";
		} else {
			echo "index.php";
		}?>');return document.MM_returnValue" value="Cancel" />
    </p>
    <div id="errorBox" style="display:none;">Some fields are incomplete, please scroll up to correct them.</div>
  </blockquote>
  </div>
</form>
<script type="text/javascript">
<!--
var sprytextarea1 = new Spry.Widget.ValidationTextarea("contentCheck");
//-->
</script>
</body>

</html>
<?php }?>