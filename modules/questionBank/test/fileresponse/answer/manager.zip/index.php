<?php 
//Connect to datbase
	require_once('functions.php');
?>
<?php
//Go into edit mode if selected
	if (isset ($_GET['edit'])) {
		$edit = 1;
		$_SESSION['edit'] = "1";
	} elseif (isset ($_GET['unset'])) {
		$edit = 0;
		unset($_SESSION['edit']);
		
		header ("Location: index.php");
		exit;
	}
?>
<?php
//Reorder the announcements
	if (isset ($_SESSION['manage'])) {
		if (isset ($_GET['id']) && isset($_GET['position']) && isset ($_GET['currentPosition'])) {
		//Grab all necessary data	
			//Grab the id of the moving item
			$id = $_GET['id'];
			//Grab the new position of the item
			$newPosition = $_GET['position'];
			//Grab the old position of the item
			$currentPosition = $_GET['currentPosition'];
				
		//Do not process if item does not exist
			//Get item name by URL variable
			$getItemID = $_GET['position'];
		
			$itemCheckGrabber = mysql_query("SELECT * FROM pages WHERE position = {$getItemID}", $connDBA);
			$itemCheckArray = mysql_fetch_array($itemCheckGrabber);
			$itemCheckResult = $itemCheckArray['position'];
				 if (isset ($itemCheckResult)) {
					 $itemCheck = 1;
				 } else {
					$itemCheck = 0;
				 }
		
		//If the item is moved up...
			if ($currentPosition > $newPosition) {
			//Update the other items first, by adding a value of 1
				$otherPostionReorderQuery = "UPDATE pages SET position = position + 1 WHERE position >= '{$newPosition}' AND position <= '{$currentPosition}'";
				
			//Update the requested item	
				$currentItemReorderQuery = "UPDATE pages SET position = '{$newPosition}' WHERE id = '{$id}'";
				
			//Execute the queries
				$otherPostionReorder = mysql_query($otherPostionReorderQuery, $connDBA);
				$currentItemReorder = mysql_query ($currentItemReorderQuery, $connDBA);
		
			//No matter what happens, the user will see the updated result on the editing screen. So, just redirect back to that page when done.
				header ("Location: index.php?edit");
				exit;
		//If the item is moved down...
			} elseif ($currentPosition < $newPosition) {
			//Update the other items first, by subtracting a value of 1
				$otherPostionReorderQuery = "UPDATE pages SET position = position - 1 WHERE position <= '{$newPosition}' AND position >= '{$currentPosition}'";
		
			//Update the requested item		
				$currentItemReorderQuery = "UPDATE pages SET position = '{$newPosition}' WHERE id = '{$id}'";
			
			//Execute the queries
				$otherPostionReorder = mysql_query($otherPostionReorderQuery, $connDBA);
				$currentItemReorder = mysql_query ($currentItemReorderQuery, $connDBA);
				
			//No matter what happens, the user will see the updated result on the editing screen. So, just redirect back to that page when done.
				header ("Location: index.php?edit");
				exit;
			}
		}
	}
?>
<?php
//Delete an announcement
	if (isset ($_GET['id']) && isset ($_GET['position'])) {
		//Get page name by URL variable
		$getPageID = $_GET['id'];
		$getPagePosition = $_GET['position'];
	
		$pageCheckGrabber = mysql_query("SELECT * FROM pages WHERE id = {$getPageID}", $connDBA);
		$pageCheckArray = mysql_fetch_array($pageCheckGrabber);
		$pageCheckResult = $pageCheckArray['id'];
			 if (isset ($pageCheckResult)) {
				 $pageCheck = 1;
			 } else {
				$pageCheck = 0;
			 }
	 
		if (!isset ($_GET['id']) || $_GET['id'] == 0 || $pageCheck == 0) {
			header ("Location: index.php");
			exit;
		} else {
			$deletePage = $_GET['id'];
			
			$pagePositionGrabber = mysql_query("SELECT * FROM pages WHERE id = {$deletePage}", $connDBA);
			$pagePositionFetch = mysql_fetch_array($pagePositionGrabber);
			$pagePosition = $pagePositionFetch['position'];
			
			$otherPagesUpdateQuery = "UPDATE pages SET position = position-1 WHERE position > '{$getPagePosition}'";
			$deletePageQueryResult = mysql_query($otherPagesUpdateQuery, $connDBA);
			
			$deletePageQuery = "DELETE FROM pages WHERE id = {$deletePage} LIMIT 1";
			$deletePageQueryResult = mysql_query($deletePageQuery, $connDBA);
			
			if ($deletePageQueryResult) {
				if (isset($_SESSION['edit'])) {
					header ("Location: index.php?edit");
					exit;
				} else {
					header ("Location: index.php");
					exit;
				}
			}
		}
	}
?>
<?php
//Upload processer
	//Check to see what type of file is being uploaded
	if (isset ($_POST['fileType'])) {
		$fileType = $_POST['fileType'];
	}
	
	if (isset($_POST['submit']) && isset ($_POST['fileType'])) {
	//If the file is a script, then do this		
		if ($fileType == "script") {
			$tempFile = $_FILES['file'] ['tmp_name'];
			$targetFile = basename($_FILES['file'] ['name']);
			$uploadDir = "files/scripts";
			
			$stripUnderscore = str_replace("_", " ", $targetFile);			
			$stripDash = str_replace("-", "", $stripUnderscore);
			$stripSlashes = str_replace("/", "", $stripDash);
			$stripSingleQuote = str_replace("'", "", $stripSlashes);
			
			function extensionSplit($stripSingleQuote) {
				$fileName = split("[/\\.]", $stripSingleQuote) ;
				$n = count($fileName)-1;
				$extensions = $fileName[$n];
				return $extensions;
			}
			
			$extension = extensionSplit($stripSingleQuote);
			$stripExentsion = str_replace ($extension, "", $stripSingleQuote);
			$stripDot = str_replace(".", "", $stripExentsion);
			$newFileName = $stripDot . "." . $extension;
			
			if (move_uploaded_file($tempFile, $uploadDir . "/" . stripslashes($newFileName))) {
				if (isset ($_SESSION['manage']) && isset($_SESSION['edit'])) {
					header ("Location: index.php?edit&uploadSuccess=script");
					exit;
				} else {
					header ("Location: index.php?uploadSuccess=script");
					exit;
				}
			} else {
				if (isset ($_SESSION['manage']) && isset($_SESSION['edit'])) {
					header ("Location: index.php?edit");
					exit;
				} else {
					header ("Location: index.php");
					exit;
				}
			}
	
	//If the file is a video, then do this
		} elseif ($fileType == "video") {
			$tempFile = $_FILES['file'] ['tmp_name'];
			$targetFile = basename($_FILES['file'] ['name']);
			$uploadDir = "files/videos";
			
			$stripUnderscore = str_replace("_", " ", $targetFile);			
			$stripDash = str_replace("-", "", $stripUnderscore);
			$stripSlashes = str_replace("/", "", $stripDash);
			$stripSingleQuote = str_replace("'", "", $stripSlashes);
			
			function extensionSplit($stripSingleQuote) {
				$fileName = split("[/\\.]", $stripSingleQuote) ;
				$n = count($fileName)-1;
				$extensions = $fileName[$n];
				return $extensions;
			}
			
			$extension = extensionSplit($stripSingleQuote);
			$stripExentsion = str_replace ($extension, "", $stripSingleQuote);
			$stripDot = str_replace(".", "", $stripExentsion);
			$newFileName = $stripDot . "." . $extension;
			
			if (move_uploaded_file($tempFile, $uploadDir . "/" . stripslashes($newFileName))) {
				if (isset ($_SESSION['manage']) && isset ($_SESSION['edit'])) {
					header ("Location: index.php?edit&uploadSuccess=video");
					exit;
				} else {
					header ("Location: index.php?uploadSuccess=video");
					exit;
				}
			} else {
				if (isset ($_SESSION['manage']) && isset ($_SESSION['edit'])) {
					header ("Location: index.php?edit");
					exit;
				} else {
					header ("Location: index.php");
					exit;
				}
			}
		} else {
			if (isset ($_SESSION['manage']) && isset ($_SESSION['edit'])) {
				header ("Location: index.php?edit&uploadError");
				exit;
			} else {
				header ("Location: index.php?uploadError");
				exit;
			}
		}
	}
?>
<?php
//The schedule processor
	if (isset ($_POST['scheduleUpdate'])) {
		$script = serialize($_POST['scriptComplete']);
		$video = serialize($_POST['videoComplete']);
		$id = $_POST['id'];

		mysql_query("UPDATE schedule SET `writerComplete` = '{$script}', `producerComplete` = '{$video}' WHERE id = '{$id}'", $connDBA);
		
		if (isset ($_SESSION['edit'])) {
			header ("Location: index.php?edit");
			exit;
		} else {
			header ("Location: index.php");
			exit;
		}
	}
?>
<?php
//Remove current schedule
	if (isset ($_SESSION['manage'])) {
	  	if (isset ($_GET['removeSchedule']) && isset ($_GET['id'])) {
			
			$id = $_GET['id'];			
			$otherItemsUpdateQuery = "UPDATE schedule SET id = id-1 WHERE id > '{$id}'";
			$deleteItemsQueryResult = mysql_query($otherPagesUpdateQuery, $connDBA);
			
			$deleteItemQuery = "DELETE FROM schedule WHERE id = {$id} LIMIT 1";
			$deleteItemQueryResult = mysql_query($deleteItemQuery, $connDBA);
			
			if (isset ($_SESSION['manage']) && isset ($_SESSION['edit'])) {
				header ("Location: index.php?edit");
				exit;
			} else {
				header ("Location: index.php");
				exit;
			}
		}
	}	
?>
<?php
//Delete a file
	if (isset($_GET['type']) && isset($_GET['name'])) {
		$file = $_GET['name'];
		$type = $_GET['type'];
		
		if ($type == "video") {
			if (file_exists('files/videos')) {
				unlink('files/videos/' . $file);
			}
			
			if (isset ($_SESSION['edit'])) {
				header ("Location: index.php?edit");
				exit;
			} else {
				header ("Location: index.php");
				exit;
			}
		} elseif ($type == "script") {
			if (file_exists('files/scripts')) {
				unlink('files/scripts/' . $file);
			}
			
			if (isset ($_SESSION['edit'])) {
				header ("Location: index.php?edit");
				exit;
			} else {
				header ("Location: index.php");
				exit;
			}
		}
	}
?>
<?php
//Process the fileshare control
	if (isset ($_SESSION['manage'])) {
		if (isset ($_GET['action']) && $_GET['action'] == "fileShare") {
			$fileShare = $_POST['control'];
			mysql_query("UPDATE fileshare SET visible = '{$fileShare}'", $connDBA);
			if (isset ($_SESSION['edit'])) {
				header ("Location: index.php?edit");
				exit;
			} else {
				header ("Location: index.php");
				exit;
			}
		}
	}
?>
<?php
//If the user is requesting to edit the page, ensure they are logged in
	if (isset ($_GET['edit']) && !isset($_SESSION['manage'])) {
		header ("Location: login.php");
		exit;
	} else {
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Bell Productivity Manager</title>

<script type="text/javascript" src="javascripts/checkBox/checkBoxCore.js"></script>
<script type="text/javascript" src="javascripts/checkBox/checkBoxOptions.js"></script>
<script type="text/javascript" src="javascripts/common/showHide.js"></script>
<link href="styles/common/style.css" rel="stylesheet" type="text/css" />
<link href="styles/checkBox/checkBoxStyle.css" rel="stylesheet" type="text/css" />
<link href="http://pavcs.blackboard.com/ui/styles/blackboard.css" rel="stylesheet" type="text/css" />
<link href="http://pavcs.blackboard.com/ui/styles/palette.css" rel="stylesheet" type="text/css" />
<link href="http://pavcs.blackboard.com/ui/styles/grid.css" rel="stylesheet" type="text/css" />
</head>
<body onload="MM_showHideLayers('alert','','hide')">
<table border="0" cellpadding="0" cellspacing="0" width="100%">
  <tbody>
    <tr>
      <td class="bLight" valign="middle"><span class="breadcrumb"> <a href="http://pavcs.blackboard.com/bin/common/course.pl?course_id=_624_1" target="content">THE PAVCS BELL NEWS MAGAZINE (ORG_KILBERT) </a></span><span class="breadcrumb">&gt; Bell Productivity Manager</span></td>
      <td class="bLight" align="right" nowrap="nowrap"><span class="breadcrumb">
      <?php
	  //Display the "Edit View" or "Display View" button as needed, if the user is logged in
		  if (isset ($_SESSION['manage'])) {
			  if (isset($edit)) {
				  echo "<a href=\"index.php?unset\">Display view</a>";
			  } else {
				  echo "<a href=\"index.php?edit\">Edit view</a>";
			  }
		  }
	  ?>
      </span></td>
    </tr>
    <tr height="5">
      <td>&nbsp;</td>
    </tr>
  </tbody>
</table>
<h1 style="font-size: 16.625px; line-height: 20px;" class="pageTitle"><img src="http://pavcs.blackboard.com/images/ci/sets/set08/document_on.gif" alt="Object" align="absmiddle" border="0" />
  Bell Productivity Manager</h1>
<?php
//Display a pop-up message if the script was uploaded
	if (isset ($_GET['uploadSuccess']) && $_GET['uploadSuccess'] == "script") {
		successMessage("The script was successfully uploaded.");
	} 
?>
<?php
//Display a pop-up message if the video was uploaded	
	if (isset ($_GET['uploadSuccess']) && $_GET['uploadSuccess'] == "video") {
		successMessage("The video was successfully uploaded.");
	}
?>
<?php
//Display a pop-up message if neither a video nor a script were selected on upload
	if (isset ($_GET['uploadError'])) {
		errorMessage("Please select the type of file you are uploading from the drop-down menu.");
	} 
?>
<hr size="2" noshade="noshade" style="color: #CCCCCC" />
<?php
//Display the menu bar if the user is in editing mode
	if (isset($edit)) {
		echo "<table class=\"bMedium\" summary=\"\" border=\"0\" cellpadding=\"1\" cellspacing=\"0\" width=\"100%\">          
				<tr>                  
					<td>                
					<table class=\"bLight\" border=\"0\" cellpadding=\"3\" cellspacing=\"0\">
						<tr>
						<td nowrap=\"nowrap\"><span class=\"skipLinks\">
						<img src=\"http://pavcs.blackboard.com/images/ci/misc/skipnav.gif\" alt=\"Skip the Action Bar links\" border=\"0\">
						<span class=\"actionType\"></span>
						</td>      
						<td nowrap=\"nowrap\">        
						<span class=\"actionItem\"><a class=\"actionItem\" href=\"announcement.php\"><img src=\"http://pavcs.blackboard.com/images/ci/actionbar/itemadd.gif\" align=\"absmiddle\" border=\"0\">&nbsp;Announcement</a></span></td>";

					echo "<td nowrap=\"nowrap\"><span class=\"actionItem\"><a class=\"actionItem\" href=\"schedule.php\">
						  <img src=\"http://pavcs.blackboard.com/images/ci/actionbar/itemadd.gif\" align=\"absmiddle\" border=\"0\">&nbsp;Schedule</a></span></td>";
					
				//Grab the current setting for the fileshare tool
				$fileShareGrabber = mysql_query("SELECT * FROM fileshare WHERE id = '1'", $connDBA);
				$fileShare = mysql_fetch_array($fileShareGrabber);
						  echo"<td width=\"100%\"><div align=\"right\" style=\"padding-right:10px;\">
						  <form name=\"fileShareControl\" action=\"index.php?action=fileShare\" method=\"post\">
						  Display file share tool: 
						  <select name=\"control\" onchange=\"this.form.submit();\">
						  <option value=\"1\""; if ($fileShare['visible'] == "1") {echo " selected=\"selected\"";} echo ">Yes</option>
						  <option value=\"0\""; if ($fileShare['visible'] == "0") {echo " selected=\"selected\"";} echo ">No</option>
						  </select>
						  </form>
						  </div>
						  </td>
						  </tr>                           
 					</table> 
				</td>                          
   			</tr>                           
		</table><br />";
//Hide the menu bar if the user is not in editing mode
	} else {
		echo "&nbsp;";
	}
?>
<table width="100%" border="0">
<?php
//The anncouncements loop
	$pageGrabber = mysql_query("SELECT * FROM pages ORDER BY position ASC", $connDBA);
		if (!$pageGrabber) {
			errorMessage("The pages could not be found.");
		}
	
	//Check to see if pages exist
	$pageCheckGrabber = mysql_query("SELECT * FROM pages WHERE position = 1", $connDBA);
	$pageCheckArray = mysql_fetch_array($pageCheckGrabber);
	$pageCheckResult = $pageCheckArray['position'];
		 if (empty ($pageCheckResult)) {
			 $pageCheck = 1;
		 } else {
			$pageCheck = 0;
		 }
	$endCheckGrabber = mysql_query("SELECT * FROM pages ORDER BY position DESC LIMIT 1", $connDBA);
	if (!$endCheckGrabber) {
		errorMessage("The pages could not be found.");
	}
	
	$numberCheck = mysql_num_rows($pageGrabber);
	$defaultNumber = $numberCheck+1;
		 
	$numberCheck = mysql_num_rows($pageGrabber);
	$endCheck = mysql_fetch_array($endCheckGrabber);
	
	if ($pageCheck == 0) {
		while($pageData = mysql_fetch_array($pageGrabber)) {
			echo "<form action=\"index.php\"><tr><td valign=\"top\" width=\"42\"><span class=\"pageTitle\"><img src=\"http://pavcs.blackboard.com/images/ci/sets/set08/document_on.gif\" alt=\"Object\" align=\"absmiddle\" border=\"0\" /></span></td>";
			echo "<td>";
			if (isset ($_GET['edit'])) {
			echo "<select name=\"position\" onchange=\"this.form.submit();\">";
					$pageCount = mysql_num_rows($pageGrabber);
					for ($count=1; $count <= $pageCount; $count++) {
						echo "<option value=\"{$count}\"";
						if ($pageData ['position'] == $count) {
							echo "selected=\"selected\"";
						}
						echo ">$count</option>";
					}
				echo "</select>";
				echo "<input type=\"hidden\" name=\"id\" value=\"";
				echo $pageData ['id'];
				echo "\" /><input type=\"hidden\" name=\"currentPosition\" value=\"";
				echo $pageData ['position'];
				echo "\" />&nbsp;&nbsp;&nbsp;"; 
			}
			echo "<span class=\"label\"><font color=\"#000000\">";
			echo stripslashes($pageData['title']);
			echo "</font></span><br>";
			echo stripslashes($pageData['content']);
			echo "</td>";
			echo "<td width=\"10%\" valign=\"top\">";
			if (isset($edit)) {
				echo "<a href=\"announcement.php?ann=" . $pageData['position'] . "\" class=\"inlineAction\">Modify</a>&nbsp;&nbsp;&nbsp;<a href=\"index.php?id=" . $pageData['id'] . "&position=" . $pageData['position'] . "\" onclick=\"return confirm ('This action cannot be undone. Continue?');\" class=\"inlineAction\">Remove</a>";
			} else {
				echo "&nbsp;";
			}
			echo "</td></tr></form>";
		}
	}
?>
<?php
//The schedule loop
//Check to see any tasks exist
	$taskCheckGrabber = mysql_query("SELECT * FROM schedule", $connDBA);
	$taskCheckArray = mysql_fetch_array($taskCheckGrabber);
	$taskCheckResult = $taskCheckArray['name'];
		 if (empty ($taskCheckResult)) {
			 $taskCheck = 1;
		 } else {
			$taskCheck = 0;
		 }
		 
//Echo the items
	if ($taskCheck == 0) {
		$valueGrabber = mysql_query("SELECT * FROM schedule ORDER BY id ASC", $connDBA);	
		while ($value = mysql_fetch_array($valueGrabber)) {
		echo "<tr>
			  <td align=\"center\" valign=\"top\" width=\"42\"><span class=\"pageTitle\"><img src=\"http://pavcs.blackboard.com/images/ci/sets/set08/document_on.gif\" alt=\"Object\" align=\"absmiddle\" border=\"0\" /></span></td>
			  <td align=\"left\" valign=\"top\"><strong><font color=\"#000000\">" . stripslashes ($value['title']) .  "</font></strong>
			  <p><font color=\"#000000\">" . stripslashes ($value['description']) . "</font></p>
			  <blockquote>";
				$items = unserialize($value['name']);
				
				echo "Writer due Date: <strong>" . stripslashes ($value['writerDate']) . "</strong><br />";
				echo "Producer due Date: <strong>" . stripslashes ($value['producerDate']) . "</strong><br />";
				echo "Debut: <strong>" . stripslashes ($value['debut']) . "</strong><br />";
				echo "<br />";
				
				
				echo "<form action=\"index.php\" method=\"post\">";
				echo "<table><tbody><tr><td valign=\"top\">";
				
				echo "<table width=\"320\" style=\"border-spacing:0;\">";
				echo "<tr background=\"images/common/headerBackground.gif\" style=\"color:#D8325D; height:21px; padding:10px;\"><td width=\"320\"><div align=\"center\">Feature Name</div></td></tr>";
				while (list($itemKey, $itemArray) = each($items)) {
					echo "<tr><td style=\"padding:10px;\"><strong>" . stripslashes ($itemArray) . "</strong></td></tr>";
				}
				echo "</table>";
				echo "</td><td valign=\"top\">";
				echo "<table width=\"100\" style=\"border-spacing:0;\">";
				echo "<tr background=\"images/common/headerBackground.gif\" style=\"color:#D8325D; height:21px; padding:10px;\"><td width=\"320\"><div align=\"center\">Written</div></td></tr>";
				$start = sizeof (unserialize($value['name']));
				for ($i = 1; $i <= $start; $i++) {
					echo "<tr><td style=\"padding:8px;\"><div style=\"padding:2px;\"><div align=\"center\"><input type=\"hidden\" name=\"id\" id=\"id\" value=\"" . $value['id'] . "\"><label><input type=\"checkbox\" name=\"scriptComplete[]\" id=\"scriptComplete[]\" value=\"";
					echo $i;
					echo "\"";
					if (is_array (unserialize($value['writerComplete']))) {
						$items = unserialize($value['writerComplete']);
						while (list($itemKey, $itemArray) = each($items)) {
							if ($i == $itemArray) {
								echo " title=\"Click to Mark as Incomplete\" checked=\"checked\"";
							} else {
								echo " title=\"Click to Mark as Complete\"";
							}
						}
					}
					echo " onclick=\"this.form.submit();\" /></label></div></div></td></tr>";
				}
				echo "</table>";
				echo "</td><td valign=\"top\">";
				echo "<table width=\"100\" style=\"border-spacing:0;\">";
				echo "<tr background=\"images/common/headerBackground.gif\" style=\"color:#D8325D; height:21px; padding:10px;\"><td width=\"320\"><div align=\"center\">Produced</div></td></tr>";
				$start = sizeof (unserialize($value['name']));
				for ($i = 1; $i <= $start; $i++) {
					echo "<tr><td style=\"padding:8px;\"><div style=\"padding:2px;\"><div align=\"center\"><input type=\"hidden\" name=\"id\" id=\"id\" value=\"" . $value['id'] . "\"><input type=\"hidden\" name=\"scheduleUpdate\" id=\"scheduleUpdate\" value=\"update\"><label><input type=\"checkbox\" name=\"videoComplete[]\" id=\"videoComplete[]\" value=\"";
					echo $i;
					echo "\"";
					if (is_array (unserialize($value['producerComplete']))) {
						$items = unserialize($value['producerComplete']);
						if ($i == $itemArray) {
							echo " title=\"Click to Mark as Incomplete\" checked=\"checked\"";
						} else {
							echo " title=\"Click to Mark as Complete\"";
						}
					}
					echo " onclick=\"this.form.submit();\" /></label></div></div></td></tr>";
				}
				echo "</table>";
				echo "</td></tr></tbody></table>";
				echo "</form>";
				echo "</blockquote>
			  <p>&nbsp;</p>
			  </td>
			  <td valign=\"top\" width=\"10%\">";
			  if (isset($edit)) {
				echo "<a href=\"schedule.php?id=" . $value['id'] . "\" class=\"inlineAction\">Modify</a>&nbsp;&nbsp;&nbsp;<a href=\"index.php?removeSchedule&id=" . $value['id'] . "\"\" onclick=\"return confirm ('This action cannot be undone. Continue?');\" class=\"inlineAction\">Remove</a>";
			} else {
				echo "&nbsp;";
			}
			  echo"</td>
			</tr>";
		}
	}	 
?>
<?php
//Only display the fileshare tool if it is set to be displayed
	$fileShareGrabber = mysql_query("SELECT * FROM fileshare WHERE id = '1'", $connDBA);
	$fileShare = mysql_fetch_array($fileShareGrabber);
	if ($fileShare['visible'] == "1") {
?>
    <tr><td width="42" valign="top"><span class="pageTitle"><img src="http://pavcs.blackboard.com/images/ci/sets/set08/document_on.gif" alt="Object" align="absmiddle" border="0" /></span></td>
    <td style=""><form action="index.php" method="post" enctype="multipart/form-data" name="upload" id="upload" onsubmit="MM_showHideLayers('alert','','show')">
      <span class="label"><font color="#000000">Upload a File</font></span>
      <blockquote>
        <p>
          <input name="file" type="file" id="file" size="50" />
          <br />
        Max file size: <?php echo ini_get('upload_max_filesize'); ?></p>
        <div id="alert"><span class="require">Upload in progress...</span> <img src="images/common/loading.gif" alt="Uploading" width="16" height="16" /></div>
      </blockquote>
      <p>What kind of file are you uploading?</p>
      <blockquote>
        <select name="fileType" id="fileType">
          <option value="NULL" selected="selected">- Select -</option>
          <option value="script">Script</option>
          <option value="video">Video</option>
        </select>
        <p>
          <input name="submit" type="submit" id="submit" value="Upload" />
        </p>
      </blockquote>
    </form>
      <table width="100%" border="0">
        <tr>
          <td width="50%" valign="top"><div style="border:thin solid black; padding:1px;">
              <div style="background-color:#006699; color:#FFFFFF; padding: 2px;"> Scripts </div>
       <?php
		  //Link to scripts directory
		  $scriptsDirectory = opendir('files/scripts');
		  
			echo "<table width=\"100%\" border=\"0\">";
					//List all files in videos directory
					while ($scripts = readdir($scriptsDirectory)) {
						//Leave out the "." and the ".."
						if (($scripts !== ".") && ($scripts !== "..")) {
							$scriptCheck = $scripts;
							echo "<tr>";
								echo "<td width=\"85%\" valign=\"top\" align=\"left\">";
									echo "<a href=\"files/scripts/" . $scripts . "\">" . $scripts . "</a>"; 
								echo "</td>";
								echo "<td width=\"15%\" valign=\"top\" align=\"right\">";
									echo "<a href=\"index.php?type=script&name=" . urlencode ($scripts) . "\" onclick=\"return confirm ('This action cannot be undone. Continue?');\" class=\"inlineAction\">" . "Remove" . "</a>";
								echo "</td>";
							echo "</tr>";
						} 
					}
					echo "</table>";
					
					if (!isset ($scriptCheck)) {
						echo "There are no scripts.";
					}
		  ?>
          </div></td>
          <td width="50%" align="left" valign="top"><div style="border:thin solid black; padding:1px;">
              <div style="background-color:#006699; color:#FFFFFF; padding: 2px;"> Videos </div>
            <?php
			  //Link to videos directory
			  $videosDirectory = opendir('files/videos');
		  
				echo "<table width=\"100%\" border=\"0\">";
					//List all files in videos directory
					while ($videos = readdir($videosDirectory)) {
						//Leave out the "." and the ".."
						if (($videos !== ".") && ($videos !== "..")) {
							$videoCheck = $videos;
							echo "<tr>";
								echo "<td width=\"85%\" valign=\"top\" align=\"left\">";
									echo "<a href=\"files/videos/" . $videos . "\">" . $videos . "</a>"; 
								echo "</td>";
								echo "<td width=\"15%\" valign=\"top\" align=\"right\">";
									echo "<a href=\"index.php?type=video&name=" . urlencode ($videos) . "\" onclick=\"return confirm ('This action cannot be undone. Continue?');\" class=\"inlineAction\">" . "Remove" . "</a>";
								echo "</td>";
							echo "</tr>";
						} 
					}
					echo "</table>";
					
					if (!isset ($videoCheck)) {
						echo "There are no videos.";
					}

			?>
          </div></td></tr>
      </table>
     </td>
    <td width="10%">&nbsp;</td>
  </tr>
<?php
//End the fileshare tool
	}
?>
  </tbody>
</table>
<?php } ?>
</body>
</html>