<?php
session_start();
ob_start();

//The password
	$password = "crew0012";
//Process the form
	if (isset($_POST["password"]) && ($_POST["password"]=="$password")) {
		$_SESSION['manage'] = "allow";
		header ("Location: index.php");
		exit;
	}
?>
<html>
    <head>
        <title>Login</title>
    </head>
    <body>
    	<form method="post" action="login.php">
            <table width="750" border="0" align="center">
              <tr>
                <td colspan="2" valign="top"><div align="center"><p>Please enter your password for access.</p></div></td>
              </tr>
              <tr>
                <td width="50%" valign="top"><div align="right"><strong>Password:</strong></div></td>
                <td width="50%" valign="top"><div align="left"><input name="password" type="password" size="25" id="password" /></div></td>
              </tr>
              <tr>
                <td valign="top">&nbsp;</td>
                <td valign="top"><div align="left"><input value="Login" type="submit" /></div></td>
              </tr>
            </table>
         </form>
    </body>
</html>